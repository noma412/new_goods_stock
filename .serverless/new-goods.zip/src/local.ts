import stock from './app'
stock()
